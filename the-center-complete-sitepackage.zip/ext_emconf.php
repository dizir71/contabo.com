<?php
$EM_CONF[$_EXTKEY] = [
    'title' => 'The Center Sitepackage',
    'description' => 'Modernes, sicheres Sitepackage für the-center.net mit Fokus auf TYPO3, Python, WordPress und Security Audits.',
    'category' => 'templates',
    'author' => 'Roland Simmer',
    'author_email' => 'kontakt@the-center.net',
    'state' => 'stable',
    'version' => '1.0.0',
    'constraints' => [
        'depends' => [
            'typo3' => '13.4.0-13.4.99',
        ],
        'conflicts' => [],
        'suggests' => [],
    ],
];